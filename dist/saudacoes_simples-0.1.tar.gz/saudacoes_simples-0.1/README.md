# Saudacoes Simples

Este é um pacote simples para dizer olá e adeus para qualquer pessoa!

## Como usar

```python
from saudacoes import dizer_ola, dizer_adeus

print(dizer_ola("João"))  # Vai dizer "Olá, João!"
print(dizer_adeus("Maria"))  # Vai dizer "Adeus, Maria!"


