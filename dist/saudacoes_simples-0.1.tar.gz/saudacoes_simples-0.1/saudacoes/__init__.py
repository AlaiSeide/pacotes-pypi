# função para dizer olá
def dizer_ola(nome):
    return f"Olá, {nome}!"

# função para dizer adeus
def dizer_adeus(nome):
    return f"Adeus, {nome}!"
